from pathlib import Path
from Bio import SeqIO

# caminho relativo para os arquivos ab1
path_to_ab1_files = Path('data/input/ab1/')
ab1_files = path_to_ab1_files.glob('*.ab1')

# conversão de todos arquivos ab1 para o formato fasta
for file in ab1_files:
    records = SeqIO.parse(file, "abi")
    SeqIO.write(records, "{}.fasta".format(str(file)[0:-4]), "fasta")
    print('Conversão do arquivo "{}" realizada com sucesso e foi salvo no diretório data/input/fasta/ ;)'.format(str(file)[15:34]))