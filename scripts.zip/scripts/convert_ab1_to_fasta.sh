# conversão 
python3 scripts/convert_ab1_to_fasta.py

# mover arquivos convertidos para o diretório data/input/fasta/
mv data/input/ab1/*.fasta data/input/fasta