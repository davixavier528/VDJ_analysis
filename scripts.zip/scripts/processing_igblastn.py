from pathlib import Path
import pandas as pd

# importar arquivos .blastn
path_to_igblastn_files = Path( 'data/output/' )
igblastn_files         = path_to_igblastn_files.glob( '*.igblastn' )

# lista vazias que serão preenchidas com informações dos arquivos
id           = [] # info 1
chain        = [] # info 2
productive   = [] # info 3
top_V_gene   = [] # info 4
top_D_gene   = [] # info 5
top_J_gene   = [] # info 6
CDR_sequence = [] # info 7
CDR_size     = [] # info 8
mutations    = [] # info 9

# loop para iterar sobre todas as linhas de todos os arquivos .blastn, buscando informações e preenchendo as listas acima
for file in igblastn_files:

    # início da estratégia para selecionar a linha que possui as informações 2, 3, 4, 5 e 6
    # isolar "top_V_gene" e armazenar na variável "occurence"
    with open(file) as f:

        lines = f.readlines()[12:13]
        ls = str(lines).split()
        occurence = ls[0].replace("['","")
    
    with open(file) as f:

        lines = f.readlines()[6:]

        for line in lines:
            
            # seleção da linha que possui a informação 1
            if line.startswith( "Query= " ):
                id.append(line[7:10])

            # seleção da linha que possui as informações 2, 3, 4, 5 e 6 de sequência de cadeias pesadas
            # o objetivo é selecionar a linha que inicie com "occurence" e que apresente 9 informações:
            # esse critério é obedecido somente para a linha de interesse da cadeia pesada, uma vez que apresenta a ...
            # informação adiconal do gene D
            if line.startswith( occurence ) and len(line.split()) == 9:
                
                ls = line.split()

                chain.append(ls[3])      
                productive.append(ls[6]) 
                top_V_gene.append(ls[0]) 
                top_D_gene.append(ls[1]) 
                top_J_gene.append(ls[2]) 

            # seleção da linha que possui as informações 2, 3, 4, 5 e 6 de sequência de cadeias leves
            # o objetivo é selecionar a linha que inicie com "occurence" e que apresente 8 informações:
            # esse critério é obedecido somente para a linha de interesse da cadeia leve, uma vez que não apresenta a ...
            # informação adiconal do gene D
            if line.startswith( occurence ) and len(line.split()) == 8:
                
                ls = line.split()

                chain.append(ls[2])      
                productive.append(ls[5]) 
                top_V_gene.append(ls[0]) 
                top_D_gene.append("Não possui") 
                top_J_gene.append(ls[1]) 
            
            # seleção da linha que possui a informação 7 e 8, para as sequências que não apresentam CDR no IMGT
            if "Total identifiable CDR3 = 0" in line:
                CDR_sequence.append("0")
                CDR_size.append("0")

            # seleção da linha que possui a informação 7 e 8, para as sequências que apresentam CDR no IMGT
            if line.startswith( "CDR3	" ):
                ls = line.split()
                CDR_sequence.append(ls[2])
                CDR_size.append(len(ls[2]))

            # seleção da linha que possui a informação 9
            if line.startswith( "Total	N/A	N/A	" ):
                ls = line.split()
                mutations.append(ls[5])

# montagem da tabela
df = pd.DataFrame (
    data    = zip ( id , chain , productive , top_V_gene , top_D_gene , top_J_gene , CDR_sequence , CDR_size , mutations ) ,
    columns = [ "Identificador" , "Cadeia" , "Produtiva" , "Top V gene" , "Top D gene" , "Top J gene" , "Sequência do CDR" , "Tamanho do CDR" , "Quantidade de mutações" ]
    )

# exportação para o excel
df.to_excel("data/output/Resultados_finais.xlsx", index = False)

print("Os resultados foram formatados e compilados no arquivo 'Resultados_finais.xlsx' e salvo no diretório data/output/ ;)")