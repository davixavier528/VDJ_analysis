#!/bin/bash

# permissão de execução para alguns executáveis
chmod -R u+x scripts/

echo "O script está corretamente configurado ;)"