#!/bin/bash

# o executável do ncbi requer que estejamos no mesmo diretório, por isso a navegação
cd scripts/ncbi-igblast-1.20.0

# loop para iterar sobre os arquivos fasta, fazendo a análise de todos
for file in ../../data/input/fasta/*.fasta;
do
    ./bin/igblastn -query $file -auxiliary_data optional_file/human_gl.aux  -germline_db_V database/human_V_germline -germline_db_D database/human_D_germline -germline_db_J database/human_J_germline > ../../data/output/$(basename "$file" .fasta).igblastn 
    echo "A análise do arquivo $(basename "$file" .fasta) foi realizada com sucesso e os resultados salvos no diretório data/output/ ;)"
done